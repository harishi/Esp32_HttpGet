#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "esp_wifi.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"

#include "lwip/sockets.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"

#include "esp_log.h"
#include "mqtt_client.h"
#include "cJSON.h" // Include cJSON library

static const char *TAG = "MQTT_EXAMPLE";

// WiFi credentials
#define WIFI_SSID "test_1"
#define WIFI_PASS "12345678"

// MQTT Broker details
#define MQTT_BROKER_URI "mqtts://a1pvn2ki7vcy3i-ats.iot.us-east-1.amazonaws.com:8883" // e.g., "mqtts://your_broker.example.com:8883"
#define MQTT_TOPIC_SUBSCRIBE "Intopic"
#define MQTT_TOPIC_PUBLISH "Intopic"

// Certificate and Key data (replace with your actual certificate and key data)
// Device certificate
// Copy and paste contents from *-certificate.pem.crt
const char *mqtt_client_cert           = "-----BEGIN CERTIFICATE-----\n"
                                         "MIIDWTCCAkGgAwIBAgIUQksYivuBgcUMMwrKmYuhlqdounswDQYJKoZIhvcNAQEL\n"
                                         "BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n"
                                         "SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTI1MDUyMDEzNDQz\n"
                                         "MloXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\n"
                                         "ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK9hY1w7TPPBRm0OvLhv\n"
                                         "GtEPOnguLVbnxHCIn4QfOHUEmJyruyWMV40qy49wqa0d9VxS4MGWQvxOrLnrf7kd\n"
                                         "t3UntbRMc9vDU1zmqqICdB25XCIOHZkexNEghv4WRXW6Up06IvpOB3hBkzqBLUI2\n"
                                         "CyObzx+CPhSDXhlTYvbQiZY7U8BBQnPNnKc1V8jLQiWnJAPgBJIsA36W80JrB1tt\n"
                                         "HiGT2xUT3ID7CDTCHO5YXoOSDtitK3JZedBL3MYQurvfX0/I7AQ069hezXZ9SnLJ\n"
                                         "6lxjjS1rDrkla8qGjjZY3nUBTW+jNNELDQST8j6yKJjqkIYlm+lzNxzQ3xQo2iPp\n"
                                         "C1cCAwEAAaNgMF4wHwYDVR0jBBgwFoAUH29WAKIt3t2WKgp+ED00//esM3YwHQYD\n"
                                         "VR0OBBYEFCd6XPNIJZb+Tk8cn+LmPiLsDRdUMAwGA1UdEwEB/wQCMAAwDgYDVR0P\n"
                                         "AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQB/BkW/oLhr9865Uf0qDv4KgYIN\n"
                                         "8NVroS1tSnUy06mirgoIJcapY+03IkEpnhsfbA0eHBvgvDFY8rixH2vu8in3Qf2u\n"
                                         "mFfs0DU/jr/LSUMtpKlOdughaWlljltBAed69xVjxFKgbOS1R8Df2B1eVpIl+x9d\n"
                                         "QfY3cNC4WQ+Yw5/14twRJ+4XWIQr0iPrDSnWQCoUjrxos7YVeEejSp1LEQEElkT6\n"
                                         "6sgbsgclQikamCJhSQVNHFsCMkngU3ThcQPeji2XIVs/uduBfFaYwSG2tNiFft47\n"
                                         "2ydZc/AeyUzvyHM4PREhxEeNYKDCWVO4r4sV34cu3ROkYYzPH6ZKPBhifIcC\n"
                                         "-----END CERTIFICATE-----\n";

// Key files / Private key file
// Copy and paste contents from *-private.pem.key
const char *mqtt_client_key       = "-----BEGIN RSA PRIVATE KEY-----\n"
                                  "MIIEogIBAAKCAQEAr2FjXDtM88FGbQ68uG8a0Q86eC4tVufEcIifhB84dQSYnKu7\n"
                                  "JYxXjSrLj3CprR31XFLgwZZC/E6suet/uR23dSe1tExz28NTXOaqogJ0HblcIg4d\n"
                                  "mR7E0SCG/hZFdbpSnToi+k4HeEGTOoEtQjYLI5vPH4I+FINeGVNi9tCJljtTwEFC\n"
                                  "c82cpzVXyMtCJackA+AEkiwDfpbzQmsHW20eIZPbFRPcgPsINMIc7lheg5IO2K0r\n"
                                  "cll50EvcxhC6u99fT8jsBDTr2F7Ndn1KcsnqXGONLWsOuSVryoaONljedQFNb6M0\n"
                                  "0QsNBJPyPrIomOqQhiWb6XM3HNDfFCjaI+kLVwIDAQABAoIBAHI63nqubTq/Al36\n"
                                  "IVWHmFHet1ibyxA1uS8K7csigqVFLxmsiSK1vDjITPnKidmmD6/ok1fDxTGNFNer\n"
                                  "2e76uglmqeUbfsL/AAccfrszGepaVvYfd4vKDKuhogtQ+kDp8PFTcoDR3e+n1nte\n"
                                  "s9nSVYMF8uw06rZ1sg6Qz36u6U6dlXzq3ygVB9uWhjSQYLiwd0j+Sb7yoVyYIUJ6\n"
                                  "dSA0mZqG1M1DE1bg1H36EQpRnr+SbeVmHSLPpGuHTnC+f6rSXajyCa3Bd1+oeOot\n"
                                  "qyQNTiQqUGdmiAq/zdIjnNXvd7a4PyMSKVXnHOCUtHTbEtyPkE2JUiLPQom35rJT\n"
                                  "GGi0V8ECgYEA3FyZLHY+khnUv6xu8dFCdabg8LRPsyBHbIKL14WM+4ZHv6WqFjXe\n"
                                  "RZ+fx6j0kl83hPeCkAKm8eh+8pyJF80mC2styTMFJhi/7yg8wmNYaFc8mnmArNst\n"
                                  "a6MLRhYbdzf2nN2UgD/jGsWGIM2iB2sqcRu3aUI5v05O0ObbHAOMRrECgYEAy756\n"
                                  "LqhWFFL5Ntox8PdqkhJCxT8xubKD+r7LRCmKDSQ/phqTjEzKYpv0ptTv09v+0cCE\n"
                                  "ZTD8MbGJ5rgwA4E8wuIBRylyn5ZJyZlh7a4Rn0ct8xB41UVmGGVE20cpEAZb2IdN\n"
                                  "ckvx2JqQIgMEBExJPUmgqTTrfsgZrRqFfTBlBIcCgYBEhpcreGnkzRuXr2ugz043\n"
                                  "f/mbYLcYIQWU/NO35dP9s7hEJKRL29yPEiCB2kyT6AA/3ShA2FJKD97KW1tWh3k5\n"
                                  "O881LiR/wFqPaJfca0Bm0hoKf5ZAKrhpLH6pAN7xp/mMtmsjprpc7OfU851baTv9\n"
                                  "iHz0wp9qmlNwKxogEApjQQKBgFGNFGrIhmvsKkSCYasJ3WZKWN+Kw+SIR7t90u6d\n"
                                  "kdxgvflGefiWZAvEUNDWOoiabgyW+mdmjAt3/LKU1uMQP7nhrJFHTdIC3dYLxt7T\n"
                                  "5cnTO9kmprb26D6rijwa55y6btjkj2NIcq04cKisfFccEdSuO9h+jiRZA63+B6Bs\n"
                                  "VoLRAoGAP5F7pNVKpIRU7b5PHNQKDXKU3ckfMNNuzslQ/fwmmn5zWVlSlZob6TVG\n"
                                  "H7tmp0RkQyzSGXjfVLQzr0C3dspWv9E03fSfirawsskETmCYjNSJ1vmi8/oVLxCH\n"
                                  "lqOTtnnAgLNbKZylxN7m4lvJHBbwZ+qww6b0MQsgmKNj3WNIf8s=\n"
                                  "-----END RSA PRIVATE KEY-----\n";

// RSA 2048 bit key: Amazon Root CA 1
// Copy and paste contents from AmazonRootCA1.cer
const char *mqtt_root_ca                 = "-----BEGIN CERTIFICATE-----\n"
                                          "MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n"
                                          "ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n"
                                          "b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n"
                                          "MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n"
                                          "b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n"
                                          "ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n"
                                          "9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n"
                                          "IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n"
                                          "VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n"
                                          "93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n"
                                          "jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n"
                                          "AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n"
                                          "A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n"
                                          "U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n"
                                          "N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n"
                                          "o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n"
                                          "5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n"
                                          "rqXRfboQnoZsG4q5WTP468SQvvG5\n"
                                          "-----END CERTIFICATE-----\n";

static esp_mqtt_client_handle_t client;

static void log_error_if_nonzero(const char *message, int err)
{
    if (err != 0) {
        ESP_LOGE(TAG, "Last error %s: 0x%x", message, err);
    }
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data)
{
    ESP_LOGD(TAG, "Event dispatched from event loop base=%s, event_id=%d", base, event_id);
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;
    esp_mqtt_client_handle_t client = event->client;
    int msg_id;
    char *json_string = NULL; // Declare json_string here
    cJSON *root = NULL;       // Declare root here

    switch ((esp_mqtt_event_id_t)event_id) {
    case MQTT_EVENT_BEFORE_CONNECT:
        ESP_LOGI(TAG, "MQTT_EVENT_BEFORE_CONNECT");
        break;
    case MQTT_EVENT_CONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
        msg_id = esp_mqtt_client_subscribe(client, MQTT_TOPIC_SUBSCRIBE, 0);
        ESP_LOGI(TAG, "sent subscribe successful, msg_id=%d", msg_id);
        break;
    case MQTT_EVENT_DISCONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
        break;
    case MQTT_EVENT_SUBSCRIBED:
        ESP_LOGI(TAG, "MQTT_EVENT_SUBSCRIBED, msg_id=%d", event->msg_id);
        //msg_id = esp_mqtt_client_publish(client, MQTT_TOPIC_PUBLISH, "data", 0, 0, 0);
        //ESP_LOGI(TAG, "sent publish successful, msg_id=%d", msg_id);


// Publish JSON data after subscribing
        root = cJSON_CreateObject();
        if (root == NULL) {
            ESP_LOGE(TAG, "Failed to create JSON object");
            break; // Exit the case if JSON object creation fails
        }
        cJSON_AddStringToObject(root, "sensor", "ESP32");
        cJSON_AddNumberToObject(root, "temperature", 25.5);
        json_string = cJSON_PrintUnformatted(root);
        if (json_string == NULL) {
            ESP_LOGE(TAG, "Failed to print JSON object");
            cJSON_Delete(root); // Clean up if printing fails
            break;             // Exit the case if printing fails
        }
        msg_id = esp_mqtt_client_publish(client, MQTT_TOPIC_PUBLISH, json_string, 0, 0, 0);
        ESP_LOGI(TAG, "sent publish successful, msg_id=%d", msg_id);
        cJSON_Delete(root);      // Delete the JSON object
        free(json_string);       // Free the JSON strin

        break;
    case MQTT_EVENT_UNSUBSCRIBED:
        ESP_LOGI(TAG, "MQTT_EVENT_UNSUBSCRIBED, msg_id=%d", event->msg_id);
        break;
    case MQTT_EVENT_PUBLISHED:
        ESP_LOGI(TAG, "MQTT_EVENT_PUBLISHED, msg_id=%d", event->msg_id);
        break;
    case MQTT_EVENT_DATA:
        ESP_LOGI(TAG, "MQTT_EVENT_DATA");
        printf("TOPIC=%.*s\r\n", event->topic_len, event->topic);
        printf("DATA=%.*s\r\n", event->data_len, event->data);
        break;
    case MQTT_EVENT_ERROR:
        ESP_LOGI(TAG, "MQTT_EVENT_ERROR");
        if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
            log_error_if_nonzero("reported from esp-tls", event->error_handle->esp_tls_last_esp_err);
            log_error_if_nonzero("underlying transport", event->error_handle->esp_tls_stack_err);
            ESP_LOGI(TAG, "Last errno string (%s)", strerror(event->error_handle->esp_transport_sock_errno));
        }
        break;
    default:
        ESP_LOGI(TAG, "Other event id:%d", event->event_id);
        break;
    }
}

static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                                int32_t event_id, void *event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        esp_wifi_connect();
        ESP_LOGI(TAG, "retry to connect to the AP");
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *)event_data;
        ESP_LOGI(TAG, "got ip:" IPSTR, IP2STR(&event->ip_info.ip));
    }
}

void wifi_init_sta(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, &instance_any_id));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL, &instance_got_ip));

    wifi_config_t wifi_config = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASS,
            .threshold.authmode = WIFI_AUTH_WPA2_PSK,
            .pmf_cfg = {
                .capable = true,
                .required = false
            },
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA) );
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config) );
    ESP_ERROR_CHECK(esp_wifi_start() );

    ESP_LOGI(TAG, "wifi_init_sta finished.");

}

static void mqtt_app_start(void)
{
    const esp_mqtt_client_config_t mqtt_cfg = {
       .broker = {
            .address.uri = MQTT_BROKER_URI,
            .verification.certificate = mqtt_root_ca,
        },
        .credentials = {
            .authentication = {
                .certificate = mqtt_client_cert,
                .key = mqtt_client_key,
            },
        },

    };

    client = esp_mqtt_client_init(&mqtt_cfg);
    /* The last argument may be used to pass data to the event handler, in this case the esp_mqtt_client handle */
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_mqtt_client_start(client);
}

void app_main(void)
{
    ESP_LOGI(TAG, "[APP] Startup..");
    ESP_LOGI(TAG, "[APP] Free memory: %" PRIu32 " bytes", esp_get_free_heap_size());
    ESP_LOGI(TAG, "[APP] IDF version: %s", esp_get_idf_version());

    esp_log_level_set("*", ESP_LOG_INFO);
    esp_log_level_set("mqtt_client", ESP_LOG_VERBOSE);
    esp_log_level_set("MQTT_EXAMPLE", ESP_LOG_VERBOSE);
    ESP_ERROR_CHECK(nvs_flash_init());

    wifi_init_sta();
    mqtt_app_start();
}
