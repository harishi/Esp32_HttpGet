#ifndef OTA_LIB_H
#define OTA_LIB_H

#include <stdint.h>
#include "esp_err.h"
#include "esp_https_ota.h"
#include "nvs.h"


// Function prototypes
void event_handler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data);
void advanced_ota_example_task(void *pvParameter);

#endif // OTA_LIB_H
