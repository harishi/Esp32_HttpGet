#ifndef COM_WIFI_H
#define COM_WIFI_H

#include <stdint.h>
#include "esp_err.h"



// Function prototypes
void wifi_connection(void);

#endif // OTA_LIB_H
