

#include <string.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>


#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "freertos/queue.h"


#include "esp_wifi.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"
#include "esp_check.h"

#include "lwip/sockets.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"

#include "mqtt_client.h"
#include "cJSON.h" // Include cJSON librar

static const char *TAG = "MQTT_DATA";

// Function declaration
void mqtt_app_start(void);

// Declare the external variables for the embedded certificate and key
extern const uint8_t server_cert_pem_start[] asm("_binary_certificate_pem_crt_start");
extern const uint8_t server_cert_pem_end[] asm("_binary_certificate_pem_crt_end");
extern const uint8_t private_key_start[] asm("_binary_private_pem_key_start");
extern const uint8_t private_key_end[] asm("_binary_private_pem_key_end");
extern const uint8_t amazon_root_ca_start[] asm("_binary_AmazonRootCA1_cer_start");
extern const uint8_t amazon_root_ca_end[] asm("_binary_AmazonRootCA1_cer_end");

// Pointers to PEM strings (cast embedded binary blobs to const char*)
const char *mqtt_client_cert = (const char *) server_cert_pem_start;
const char *mqtt_client_key  = (const char *) private_key_start;
const char *mqtt_root_ca     = (const char *) amazon_root_ca_start;

// MQTT Broker details
#define MQTT_BROKER_URI "mqtts://a1pvn2ki7vcy3i-ats.iot.us-east-1.amazonaws.com:8883" // e.g., "mqtts://your_broker.example.com:8883"
#define MQTT_TOPIC_SUBSCRIBE "Intopic/receive"
#define MQTT_TOPIC_PUBLISH "Intopic"

static esp_mqtt_client_handle_t client;



static void log_error_if_nonzero(const char *message, int err)
{
    if (err != 0) {
        ESP_LOGE(TAG, "Last error %s: 0x%x", message, err);
    }
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data)
{
    ESP_LOGD(TAG, "Event dispatched from event loop base=%s, event_id=%d", base, event_id);
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;
    esp_mqtt_client_handle_t client = event->client;
    int msg_id;
    char *json_string = NULL; // Declare json_string here
    cJSON *root = NULL;       // Declare root here

    switch ((esp_mqtt_event_id_t)event_id) {
    case MQTT_EVENT_BEFORE_CONNECT:
        ESP_LOGI(TAG, "MQTT_EVENT_BEFORE_CONNECT");
        break;
    case MQTT_EVENT_CONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
        msg_id = esp_mqtt_client_subscribe(client, MQTT_TOPIC_SUBSCRIBE, 0);
        ESP_LOGI(TAG, "sent subscribe successful, msg_id=%d", msg_id);
        break;
    case MQTT_EVENT_DISCONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
        break;
    case MQTT_EVENT_SUBSCRIBED:
        ESP_LOGI(TAG, "MQTT_EVENT_SUBSCRIBED, msg_id=%d", event->msg_id);
        root = cJSON_CreateObject();
        if (root == NULL) {
            ESP_LOGE(TAG, "Failed to create JSON object");
            break; // Exit the case if JSON object creation fails
        }
        cJSON_AddStringToObject(root, "sensor", "ESP32");
        cJSON_AddNumberToObject(root, "temperature", 25.5);
        json_string = cJSON_PrintUnformatted(root);
        if (json_string == NULL) {
            ESP_LOGE(TAG, "Failed to print JSON object");
            cJSON_Delete(root); // Clean up if printing fails
            break;             // Exit the case if printing fails
        }
        msg_id = esp_mqtt_client_publish(client, MQTT_TOPIC_PUBLISH, json_string, 0, 0, 0);
        ESP_LOGI(TAG, "sent publish successful, msg_id=%d", msg_id);
        cJSON_Delete(root);      // Delete the JSON object
        free(json_string);       // Free the JSON strin

        break;
    case MQTT_EVENT_UNSUBSCRIBED:
        ESP_LOGI(TAG, "MQTT_EVENT_UNSUBSCRIBED, msg_id=%d", event->msg_id);
        break;
    case MQTT_EVENT_PUBLISHED:
        ESP_LOGI(TAG, "MQTT_EVENT_PUBLISHED, msg_id=%d", event->msg_id);
        break;
    case MQTT_EVENT_DATA:
        ESP_LOGI(TAG, "MQTT_EVENT_DATA");
        printf("TOPIC=%.*s\r\n", event->topic_len, event->topic);
        printf("DATA=%.*s\r\n", event->data_len, event->data);
        break;
    case MQTT_EVENT_ERROR:
        ESP_LOGI(TAG, "MQTT_EVENT_ERROR");
        if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
            log_error_if_nonzero("reported from esp-tls", event->error_handle->esp_tls_last_esp_err);
            log_error_if_nonzero("underlying transport", event->error_handle->esp_tls_stack_err);
            ESP_LOGI(TAG, "Last errno string (%s)", strerror(event->error_handle->esp_transport_sock_errno));
        }
        break;
    default:
        ESP_LOGI(TAG, "Other event id:%d", event->event_id);
        break;
    }
}

void mqtt_app_start(void)
{
    const esp_mqtt_client_config_t mqtt_cfg = {
       .broker = {
            .address.uri = MQTT_BROKER_URI,
            .verification.certificate = mqtt_root_ca,
        },
        .credentials = {
            .authentication = {
                .certificate = mqtt_client_cert,
                .key = mqtt_client_key,
            },
        },

    };

    client = esp_mqtt_client_init(&mqtt_cfg);
    /* The last argument may be used to pass data to the event handler, in this case the esp_mqtt_client handle */
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_mqtt_client_start(client);
}

