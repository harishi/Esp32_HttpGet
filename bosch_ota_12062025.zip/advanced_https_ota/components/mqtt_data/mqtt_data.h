#ifndef MQTT_DATA_H
#define MQTT_DATA_H


void mqtt_app_start(void);
#endif // MQTT_DATA_H
