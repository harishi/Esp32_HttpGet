#!/usr/bin/env python3
"""
Script to update ESP-IDF sdkconfig file with values from sdkconfig.ci.esp32s3.

Usage:
    python3 update_sdkconfig.py sdkconfig sdkconfig.ci.esp32s3

This script will:
- Update existing keys with new values from sdkconfig.ci.esp32s3
- Append new keys if not present
"""

import sys
import re

def load_config_updates(config_file):
    updates = {}
    with open(config_file) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, val = line.split("=", 1)
                updates[key.strip()] = val.strip()
    return updates

def update_sdkconfig(sdkconfig_path, updates):
    try:
        with open(sdkconfig_path, "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        lines = []

    pattern = re.compile(r'^(# )?(CONFIG_[A-Z0-9_]+)(=(.*))?$')

    keys_found = set()
    new_lines = []

    for line in lines:
        m = pattern.match(line)
        if m:
            comment = m.group(1)
            key = m.group(2)
            has_value = m.group(3) is not None

            if key in updates:
                val = updates[key]
                keys_found.add(key)

                if val == "n":
                    new_lines.append(f"# {key} is not set\n")
                else:
                    if val == "y":
                        new_lines.append(f"{key}=y\n")
                    else:
                        if " " in val and not (val.startswith('"') and val.endswith('"')):
                            val = f'"{val}"'
                        new_lines.append(f"{key}={val}\n")
                continue

        new_lines.append(line)

    for key, val in updates.items():
        if key not in keys_found:
            if val == "n":
                new_lines.append(f"# {key} is not set\n")
            else:
                if val == "y":
                    new_lines.append(f"{key}=y\n")
                else:
                    if " " in val and not (val.startswith('"') and val.endswith('"')):
                        val = f'"{val}"'
                    new_lines.append(f"{key}={val}\n")

    with open(sdkconfig_path, "w") as f:
        f.writelines(new_lines)

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 update_sdkconfig.py <sdkconfig_path> <config_file>")
        sys.exit(1)

    sdkconfig_path = sys.argv[1]
    config_file = sys.argv[2]

    updates = load_config_updates(config_file)

    if not updates:
        print("No configs to update. Exiting.")
        sys.exit(0)

    update_sdkconfig(sdkconfig_path, updates)
    print(f"Updated {sdkconfig_path} with configs from {config_file}:")
    for k, v in updates.items():
        print(f"  {k} = {v}")

if __name__ == "__main__":
    main()
